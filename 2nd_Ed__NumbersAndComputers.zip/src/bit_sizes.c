#include <stdio.h>

int main() {
    printf("unsigned char      = %d\n", sizeof(unsigned char));
    printf("unsigned short     = %d\n", sizeof(unsigned short));
    printf("unsigned int       = %d\n", sizeof(unsigned int));
    printf("unsigned long      = %d\n", sizeof(unsigned long));
    printf("unsigned long long = %d\n", sizeof(unsigned long long));

    return 0;
}


